package steps;

import java.io.File;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;

public class JiraTestCases extends Common{
	
	@When("create an issue in Jira with string body {string}")	
	public void createIssue(String body)
	{
		inputRequest = RestAssured.given().contentType("application/json").body(body);
		response = inputRequest.post("issue");
		response.prettyPrint();
		jiraID = response.jsonPath().get("id");
		System.out.println("Issue ID of Create Issue with String Body is "+jiraID);
	}
	
	@When("Create an issue with multiple files {string}")
	public void createIssuewithFiles(String fileName)
	{
		File file = new File("./src/test/resources/"+fileName);
		inputRequest = RestAssured.given().contentType("application/json").body(file);
		response = inputRequest.post("issue");
		response.prettyPrint();
		
	}
	
	@When("update an issue in Jira {string}")
	public void updateIssue(String body)
	{
		inputRequest = RestAssured.given().contentType("application/json").body(body);
		response = inputRequest.put("issue/"+jiraID);
		
	}
	
	@When("Delete an issue in Jira")
	public void deleteIssue()
	{
		response = RestAssured.delete("issue/"+jiraID);
	}
	
	@Then("Validate the response code as {int}")
	public void validateResponseCode(int statusCode)
	{
		response.then().assertThat().statusCode(statusCode);
	}

}
