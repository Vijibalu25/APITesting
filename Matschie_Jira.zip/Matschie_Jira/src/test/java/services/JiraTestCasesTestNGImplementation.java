package services;

import static org.hamcrest.Matchers.containsString;

import java.io.File;
import java.util.List;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.matcher.ResponseAwareMatcher;
import io.restassured.response.Response;
import io.restassured.specification.Argument;

public class JiraTestCasesTestNGImplementation extends BaseClass_Jira {
	
	@Test
	public void createJiraIssue()
	{
		RestAssured.given().contentType("application/json").when()
		.body(new File("./src/test/resources/JiraCreateIssue_TestNG.json")).post("issue")
		.then().assertThat().statusCode(201).body(containsString("id"), containsString("AP")).extract().response();
	}
	
	@Test
	public void updateJiraIssue() {
		
		RestAssured.given().contentType("application/json").when().body(new File("./src/test/resources/JiraCreateIssue_TestNG.json")).put("issue/222235")
		.then().assertThat().statusCode(404);
		
	}
	
	
	@Test
	public void deleteJiraIssue() {
		
		RestAssured.given().contentType("application/json").when().body(new File("./src/test/resources/JiraCreateIssue_TestNG.json")).delete("issue/222235")
		.then().assertThat().statusCode(404);
		
	}
}
