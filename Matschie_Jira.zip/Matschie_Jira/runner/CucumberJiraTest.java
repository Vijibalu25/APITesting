package runner;

import org.testng.annotations.Test;

public class CucumberJiraTest {
  @Test
  public void f() {
  }
}
